document.addEventListener("DOMContentLoaded", ()=>{


});

function fetchProductFromWishList();